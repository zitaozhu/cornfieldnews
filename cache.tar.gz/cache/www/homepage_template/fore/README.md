# Fore

Fore is a free, responsive, pageless web template available for download. Use it for whatever you want! It's licensed under the <a href="http://creativecommons.org/licenses/by/3.0/">Creative Commons Attribution</a> license.

<a href="http://eatapapaya.com/Fore/fore.html">See the demo</a>

Fore is the first free template from <a href="http://eatapapaya.com">Papaya</a>.

Branches & pull requests are welcomed!