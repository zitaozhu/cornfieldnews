<?php

echo "inside sen_comment.php";

?>